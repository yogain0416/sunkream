package com.ezen.kream.dto;

public class BanDTO {
	private int user_num;
	private int ban_num;
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public int getBan_num() {
		return ban_num;
	}
	public void setBan_num(int ban_num) {
		this.ban_num = ban_num;
	}
	
}
