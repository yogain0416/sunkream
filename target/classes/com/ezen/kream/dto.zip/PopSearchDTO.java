package com.ezen.kream.dto;

public class PopSearchDTO {
	private int search_num;
	private String search_string;
	private int search_count;
	public int getSearch_num() {
		return search_num;
	}
	public void setSearch_num(int search_num) {
		this.search_num = search_num;
	}
	public String getSearch_string() {
		return search_string;
	}
	public void setSearch_string(String search_string) {
		this.search_string = search_string;
	}
	public int getSearch_count() {
		return search_count;
	}
	public void setSearch_count(int search_count) {
		this.search_count = search_count;
	}
	
}
