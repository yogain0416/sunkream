package com.ezen.kream.dto;

public class StyleLikeDTO {
	private int sytle_num;
	private int user_num;
	private String reg_date;
	public int getSytle_num() {
		return sytle_num;
	}
	public void setSytle_num(int sytle_num) {
		this.sytle_num = sytle_num;
	}
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
}
