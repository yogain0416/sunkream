package com.ezen.kream.dto;

public class StyleImgDTO {
	private int style_num;
	private int user_num;
	private String style_img1;
	private String style_img2;
	private String style_img3;
	private String style_img4;
	private String style_img5;
	public int getStyle_num() {
		return style_num;
	}
	public void setStyle_num(int style_num) {
		this.style_num = style_num;
	}
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public String getStyle_img1() {
		return style_img1;
	}
	public void setStyle_img1(String style_img1) {
		this.style_img1 = style_img1;
	}
	public String getStyle_img2() {
		return style_img2;
	}
	public void setStyle_img2(String style_img2) {
		this.style_img2 = style_img2;
	}
	public String getStyle_img3() {
		return style_img3;
	}
	public void setStyle_img3(String style_img3) {
		this.style_img3 = style_img3;
	}
	public String getStyle_img4() {
		return style_img4;
	}
	public void setStyle_img4(String style_img4) {
		this.style_img4 = style_img4;
	}
	public String getStyle_img5() {
		return style_img5;
	}
	public void setStyle_img5(String style_img5) {
		this.style_img5 = style_img5;
	}
	
}
