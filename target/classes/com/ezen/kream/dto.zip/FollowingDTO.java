package com.ezen.kream.dto;

public class FollowingDTO {
	private int user_num;
	private int following_num;
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public int getFollowing_num() {
		return following_num;
	}
	public void setFollowing_num(int following_num) {
		this.following_num = following_num;
	}
	
}
