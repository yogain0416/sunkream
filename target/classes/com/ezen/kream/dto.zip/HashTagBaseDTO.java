package com.ezen.kream.dto;

public class HashTagBaseDTO {
	private int hashTag_num;
	private String hashTag_name;
	private int hashTag_count;
	public int getHashTag_num() {
		return hashTag_num;
	}
	public void setHashTag_num(int hashTag_num) {
		this.hashTag_num = hashTag_num;
	}
	public String getHashTag_name() {
		return hashTag_name;
	}
	public void setHashTag_name(String hashTag_name) {
		this.hashTag_name = hashTag_name;
	}
	public int getHashTag_count() {
		return hashTag_count;
	}
	public void setHashTag_count(int hashTag_count) {
		this.hashTag_count = hashTag_count;
	}
}
