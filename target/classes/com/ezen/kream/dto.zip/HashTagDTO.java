package com.ezen.kream.dto;

public class HashTagDTO {
	private int hashTag_num;
	private int style_num;
	private int user_num;
	
}
