package com.ezen.kream.dto;

public class CardDTO {
	private int mycard_num;
	private int user_num;
	private int card_num;
	private String card_date;
	private String baisc;
	public int getMycard_num() {
		return mycard_num;
	}
	public void setMycard_num(int mycard_num) {
		this.mycard_num = mycard_num;
	}
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public int getCard_num() {
		return card_num;
	}
	public void setCard_num(int card_num) {
		this.card_num = card_num;
	}
	public String getCard_date() {
		return card_date;
	}
	public void setCard_date(String card_date) {
		this.card_date = card_date;
	}
	public String getBaisc() {
		return baisc;
	}
	public void setBaisc(String baisc) {
		this.baisc = baisc;
	}
	
}
