package com.ezen.kream.dto;

public class QnACateDTO {
	private int qna_cate_num;
	private String qna_cate;
	private String qna_subCate;
	public int getQna_cate_num() {
		return qna_cate_num;
	}
	public void setQna_cate_num(int qna_cate_num) {
		this.qna_cate_num = qna_cate_num;
	}
	public String getQna_cate() {
		return qna_cate;
	}
	public void setQna_cate(String qna_cate) {
		this.qna_cate = qna_cate;
	}
	public String getQna_subCate() {
		return qna_subCate;
	}
	public void setQna_subCate(String qna_subCate) {
		this.qna_subCate = qna_subCate;
	}
	
}
