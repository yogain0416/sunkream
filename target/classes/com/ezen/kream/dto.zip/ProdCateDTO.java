package com.ezen.kream.dto;

public class ProdCateDTO {
	private int cate_num;
	private String cate_brand;
	private String cate_kr_brand;
	private String cate_type;
	private String cate_kr_type;
	private String cate_subType;
	private String cate_kr_subType;
	public int getCate_num() {
		return cate_num;
	}
	public void setCate_num(int cate_num) {
		this.cate_num = cate_num;
	}
	public String getCate_brand() {
		return cate_brand;
	}
	public void setCate_brand(String cate_brand) {
		this.cate_brand = cate_brand;
	}
	public String getCate_kr_brand() {
		return cate_kr_brand;
	}
	public void setCate_kr_brand(String cate_kr_brand) {
		this.cate_kr_brand = cate_kr_brand;
	}
	public String getCate_type() {
		return cate_type;
	}
	public void setCate_type(String cate_type) {
		this.cate_type = cate_type;
	}
	public String getCate_kr_type() {
		return cate_kr_type;
	}
	public void setCate_kr_type(String cate_kr_type) {
		this.cate_kr_type = cate_kr_type;
	}
	public String getCate_subType() {
		return cate_subType;
	}
	public void setCate_subType(String cate_subType) {
		this.cate_subType = cate_subType;
	}
	public String getCate_kr_subType() {
		return cate_kr_subType;
	}
	public void setCate_kr_subType(String cate_kr_subType) {
		this.cate_kr_subType = cate_kr_subType;
	}
	
}	
