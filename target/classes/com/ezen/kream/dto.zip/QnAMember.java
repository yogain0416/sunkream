package com.ezen.kream.dto;

public class QnAMember {
	private int num;
	private String subject;
	private String writer;
	private String accused;
	private String process;
	
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getAccused() {
		return accused;
	}
	public void setAccused(String accused) {
		this.accused = accused;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
}
