package com.ezen.kream.dto;

public class ProdImgDTO {
	private int prod_num;
	private String prod_img1;
	private String prod_img2;
	private String prod_img3;
	private String prod_img4;
	private String prod_img5;
	public int getProd_num() {
		return prod_num;
	}
	public void setProd_num(int prod_num) {
		this.prod_num = prod_num;
	}
	public String getProd_img1() {
		return prod_img1;
	}
	public void setProd_img1(String prod_img1) {
		this.prod_img1 = prod_img1;
	}
	public String getProd_img2() {
		return prod_img2;
	}
	public void setProd_img2(String prod_img2) {
		this.prod_img2 = prod_img2;
	}
	public String getProd_img3() {
		return prod_img3;
	}
	public void setProd_img3(String prod_img3) {
		this.prod_img3 = prod_img3;
	}
	public String getProd_img4() {
		return prod_img4;
	}
	public void setProd_img4(String prod_img4) {
		this.prod_img4 = prod_img4;
	}
	public String getProd_img5() {
		return prod_img5;
	}
	public void setProd_img5(String prod_img5) {
		this.prod_img5 = prod_img5;
	}
	
}
