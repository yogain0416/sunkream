package com.ezen.kream.dto;

public class FollowerDTO {
	private int user_num;
	private int follower_num;
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public int getFollower_num() {
		return follower_num;
	}
	public void setFollower_num(int follower_num) {
		this.follower_num = follower_num;
	}
	
}
