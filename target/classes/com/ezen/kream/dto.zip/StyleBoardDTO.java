package com.ezen.kream.dto;

public class StyleBoardDTO {
	private int style_num;
	private int user_num;
	private String style_contents;
	private int style_like;
	private String reg_date;
	public int getStyle_num() {
		return style_num;
	}
	public void setStyle_num(int style_num) {
		this.style_num = style_num;
	}
	public int getUser_num() {
		return user_num;
	}
	public void setUser_num(int user_num) {
		this.user_num = user_num;
	}
	public String getStyle_contents() {
		return style_contents;
	}
	public void setStyle_contents(String style_contents) {
		this.style_contents = style_contents;
	}
	public int getStyle_like() {
		return style_like;
	}
	public void setStyle_like(int style_like) {
		this.style_like = style_like;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
}
